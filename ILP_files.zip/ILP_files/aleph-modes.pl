
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Module Loading Starts..
:- use_module(aleph).
:- if(current_predicate(use_rendering/1)).
:- use_rendering(prolog).
:- endif.
:- aleph.
:-style_check(-discontiguous).
%Module Loading ends..
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%This section is not related with Aleph System.
%This is to avoid the warnings.
:- multifile taughtBy/3.
:- multifile ta/3.
:- multifile tempAdvisedBy/2.
:- multifile projectMember/2.
:- multifile hasPosition/2.
:- multifile publication/2.
:- multifile inPhase/2.
:- multifile courselevel/2.
:- multifile yearsInProgram/2.
:- multifile student/1.
:- multifile professor/1.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

:- aleph_set(i,6).

:- determination(advisedBy/2, taughtBy/3).
:- determination(advisedBy/2, ta/3).
:- determination(advisedBy/2, tempAdvisedBy/2).
:- determination(advisedBy/2, projectMember/2).
:- determination(advisedBy/2, hasPosition/2).
:- determination(advisedBy/2, publication/2).
:- determination(advisedBy/2, inPhase/2).
:- determination(advisedBy/2, courselevel/2).
:- determination(advisedBy/2, yearsInProgram/2).
:- determination(advisedBy/2, student/1).
:- determination(advisedBy/2, professor/1).


:- modeh(*,advisedBy(+person,+person)).
:- modeb(*,ta(-course, -person, -term)).
:- modeb(*,taughtBy(-course, -person, -term)).
:- modeb(*,courselevel(-course, -level)).
:- modeb(*,yearsInProgram(-person, -year)).
:- modeb(*,projectMember(-project, -person)).
:- modeb(*,tempAdvisedBy(-person, -person)).
:- modeb(*,inPhase(-person, -phase)).
:- modeb(*,hasPosition(-person, -position)).
:- modeb(*,publication(-publication, -person)).
:- modeb(*,professor(-person)).
:- modeb(*,student(-person)).
:- modeb(*,advisedBy(-person, -person)).