
taughtBy(course44, person171, autumn_0001).
taughtBy(course24, person240, autumn_0001).
taughtBy(course12, person211, autumn_0001).
taughtBy(course123, person150, autumn_0001).
taughtBy(course44, person293, winter_0001).
taughtBy(course143, person211, winter_0001).
taughtBy(course50, person171, winter_0001).
taughtBy(course170, person79, winter_0001).
taughtBy(course15, person292, winter_0001).
taughtBy(course32, person319, winter_0001).
taughtBy(course158, person240, winter_0001).
taughtBy(course24, person150, spring_0001).
taughtBy(course52, person168, spring_0001).
taughtBy(course16, person240, spring_0001).
taughtBy(course173, person171, spring_0001).
taughtBy(course64, person79, spring_0001).
taughtBy(course44, person171, autumn_0102).
taughtBy(course24, person211, autumn_0102).
taughtBy(course156, person240, autumn_0102).
taughtBy(course12, person79, autumn_0102).
taughtBy(course143, person407, winter_0102).
taughtBy(course170, person211, winter_0102).
taughtBy(course44, person415, spring_0102).
taughtBy(course24, person240, spring_0102).
taughtBy(course52, person168, spring_0102).
taughtBy(course50, person171, spring_0102).
taughtBy(course39, person415, spring_0102).
taughtBy(course123, person150, spring_0102).
taughtBy(course76, person319, spring_0102).
taughtBy(course44, person171, autumn_0203).
taughtBy(course24, person240, autumn_0203).
taughtBy(course44, person415, winter_0203).
taughtBy(course52, person168, winter_0203).
taughtBy(course141, person150, winter_0203).
taughtBy(course12, person211, winter_0203).
taughtBy(course16, person79, winter_0203).
taughtBy(course24, person211, spring_0203).
taughtBy(course170, person407, spring_0203).
taughtBy(course15, person292, spring_0203).
taughtBy(course168, person240, spring_0203).
taughtBy(course64, person79, spring_0203).
taughtBy(course44, person171, autumn_0304).
taughtBy(course24, person79, autumn_0304).
taughtBy(course156, person240, autumn_0304).
taughtBy(course12, person407, autumn_0304).
taughtBy(course76, person319, autumn_0304).
taughtBy(course44, person415, winter_0304).
taughtBy(course57, person150, winter_0304).
taughtBy(course52, person168, winter_0304).
taughtBy(course170, person79, winter_0304).
taughtBy(course24, person407, spring_0304).
taughtBy(course50, person171, spring_0304).
taughtBy(course158, person240, spring_0304).
taughtBy(course7, person415, spring_0304).
courselevel(course52, level_400).
courselevel(course44, level_400).
courselevel(course24, level_400).
courselevel(course128, level_400).
courselevel(course57, level_400).
courselevel(course82, level_400).
courselevel(course143, level_400).
courselevel(course50, level_500).
courselevel(course156, level_500).
courselevel(course141, level_500).
courselevel(course12, level_500).
courselevel(course170, level_500).
courselevel(course65, level_500).
courselevel(course123, level_500).
courselevel(course173, level_500).
courselevel(course86, level_500).
courselevel(course131, level_500).
courselevel(course85, level_500).
courselevel(course64, level_500).
courselevel(course168, level_500).
courselevel(course158, level_500).
courselevel(course132, level_500).
courselevel(course76, level_500).
courselevel(course16, level_500).
courselevel(course15, level_500).
courselevel(course39, level_500).
courselevel(course32, level_500).
courselevel(course7, level_500).
courselevel(course134, level_500).
courselevel(course135, level_500).
hasPosition(person292, faculty_affiliate).
hasPosition(person293, faculty_affiliate).
hasPosition(person240, faculty).
hasPosition(person211, faculty).
hasPosition(person150, faculty).
hasPosition(person415, faculty).
hasPosition(person79, faculty).
hasPosition(person349, faculty_adjunct).
hasPosition(person7, faculty_adjunct).
hasPosition(person319, faculty).
hasPosition(person185, faculty_adjunct).
hasPosition(person171, faculty).
hasPosition(person168, faculty).
hasPosition(person407, faculty).
projectMember(project62, person319).
inPhase(person408, pre_Quals).
inPhase(person265, post_Generals).
inPhase(person70, pre_Quals).
inPhase(person381, post_Generals).
inPhase(person139, post_Quals).
inPhase(person382, post_Quals).
inPhase(person333, pre_Quals).
inPhase(person94, pre_Quals).
inPhase(person176, post_Quals).
inPhase(person272, post_Quals).
inPhase(person37, pre_Quals).
inPhase(person353, post_Quals).
inPhase(person432, post_Quals).
inPhase(person377, pre_Quals).
inPhase(person239, post_Quals).
inPhase(person13, post_Generals).
inPhase(person286, post_Quals).
inPhase(person412, post_Quals).
inPhase(person418, post_Quals).
inPhase(person14, post_Generals).
inPhase(person320, post_Quals).
inPhase(person42, pre_Quals).
inPhase(person20, pre_Quals).
inPhase(person352, post_Generals).
inPhase(person276, pre_Quals).
inPhase(person45, post_Generals).
inPhase(person233, pre_Quals).
inPhase(person148, post_Quals).
inPhase(person193, pre_Quals).
inPhase(person314, post_Generals).
inPhase(person275, post_Generals).
inPhase(person21, post_Generals).
inPhase(person262, post_Generals).
inPhase(person257, post_Generals).
inPhase(person73, post_Quals).
inPhase(person380, post_Generals).
inPhase(person384, post_Quals).
inPhase(person406, post_Generals).
inPhase(person266, post_Quals).
inPhase(person312, pre_Quals).
inPhase(person208, post_Quals).
inPhase(person311, post_Quals).
inPhase(person63, post_Generals).
inPhase(person318, pre_Quals).
inPhase(person83, post_Quals).
inPhase(person161, post_Generals).
inPhase(person284, post_Quals).
tempAdvisedBy(person408, person150).
tempAdvisedBy(person382, person415).
tempAdvisedBy(person333, person211).
tempAdvisedBy(person94, person79).
tempAdvisedBy(person377, person292).
tempAdvisedBy(person412, person168).
tempAdvisedBy(person42, person150).
tempAdvisedBy(person20, person240).
tempAdvisedBy(person233, person319).
tempAdvisedBy(person193, person415).
tempAdvisedBy(person284, person211).
yearsInProgram(person408, year_2).
yearsInProgram(person265, year_9).
yearsInProgram(person70, year_1).
yearsInProgram(person381, year_10).
yearsInProgram(person139, year_3).
yearsInProgram(person382, year_3).
yearsInProgram(person333, year_2).
yearsInProgram(person94, year_1).
yearsInProgram(person176, year_2).
yearsInProgram(person272, year_2).
yearsInProgram(person37, year_1).
yearsInProgram(person353, year_4).
yearsInProgram(person432, year_5).
yearsInProgram(person377, year_1).
yearsInProgram(person239, year_4).
yearsInProgram(person13, year_7).
yearsInProgram(person286, year_3).
yearsInProgram(person412, year_3).
yearsInProgram(person418, year_3).
yearsInProgram(person14, year_10).
yearsInProgram(person320, year_3).
yearsInProgram(person42, year_1).
yearsInProgram(person20, year_1).
yearsInProgram(person352, year_5).
yearsInProgram(person276, year_3).
yearsInProgram(person45, year_5).
yearsInProgram(person233, year_1).
yearsInProgram(person148, year_5).
yearsInProgram(person193, year_1).
yearsInProgram(person314, year_4).
yearsInProgram(person275, year_5).
yearsInProgram(person21, year_5).
yearsInProgram(person262, year_7).
yearsInProgram(person257, year_7).
yearsInProgram(person73, year_4).
yearsInProgram(person380, year_6).
yearsInProgram(person384, year_3).
yearsInProgram(person406, year_5).
yearsInProgram(person266, year_5).
yearsInProgram(person312, year_4).
yearsInProgram(person208, year_4).
yearsInProgram(person311, year_3).
yearsInProgram(person63, year_5).
yearsInProgram(person318, year_5).
yearsInProgram(person83, year_5).
yearsInProgram(person161, year_7).
yearsInProgram(person284, year_3).
ta(course52, person70, winter_0304).
ta(course44, person193, winter_0304).
ta(course128, person271, winter_0304).
ta(course128, person392, winter_0304).
ta(course44, person377, autumn_0304).
ta(course24, person70, autumn_0304).
ta(course156, person257, autumn_0304).
ta(course132, person94, autumn_0304).
ta(course24, person21, spring_0203).
ta(course44, person420, winter_0203).
ta(course44, person382, winter_0203).
ta(course141, person14, winter_0203).
ta(course12, person21, winter_0203).
ta(course44, person286, autumn_0203).
ta(course52, person318, spring_0102).
ta(course44, person382, spring_0102).
ta(course44, person86, spring_0102).
ta(course50, person314, spring_0102).
ta(course39, person73, spring_0102).
ta(course82, person381, winter_0102).
taughtBy(course128 , person150, winter_0304).
taughtBy(course132 , person319, autumn_0304).
taughtBy(course134, person240, spring_0203).
taughtBy(course82 , person407, winter_0102).
professor(person319).
student(person284).
student(person311).
student(person14).
student(person275).
student(person259).
student(person139).
student(person176).
student(person400).
student(person318).
student(person161).
student(person347).
professor(person292).
professor(person293).
professor(person240).
professor(person211).
professor(person150).
professor(person415).
professor(person79).
professor(person349).
professor(person7).
professor(person185).
professor(person171).
professor(person168).
professor(person407).
student(person408).
student(person265).
student(person70).
student(person381).
student(person382).
student(person333).
student(person94).
student(person272).
student(person37).
student(person353).
student(person432).
student(person377).
student(person239).
student(person13).
student(person286).
student(person412).
student(person418).
student(person320).
student(person42).
student(person20).
student(person352).
student(person276).
student(person45).
student(person233).
student(person148).
student(person193).
student(person314).
student(person21).
student(person262).
student(person257).
student(person73).
student(person380).
student(person384).
student(person406).
student(person266).
student(person312).
student(person208).
student(person63).
student(person83).
student(person271).
student(person392).
student(person420).
student(person86).
sameperson(person319, person319).
sameperson(person284, person284).
sameperson(person311, person311).
sameperson(person14, person14).
sameperson(person275, person275).
sameperson(person259, person259).
sameperson(person139, person139).
sameperson(person176, person176).
sameperson(person400, person400).
sameperson(person318, person318).
sameperson(person161, person161).
sameperson(person347, person347).
sameperson(person292, person292).
sameperson(person293, person293).
sameperson(person240, person240).
sameperson(person211, person211).
sameperson(person150, person150).
sameperson(person415, person415).
sameperson(person79, person79).
sameperson(person349, person349).
sameperson(person7, person7).
sameperson(person185, person185).
sameperson(person171, person171).
sameperson(person168, person168).
sameperson(person407, person407).
sameperson(person408, person408).
sameperson(person265, person265).
sameperson(person70, person70).
sameperson(person381, person381).
sameperson(person382, person382).
sameperson(person333, person333).
sameperson(person94, person94).
sameperson(person272, person272).
sameperson(person37, person37).
sameperson(person353, person353).
sameperson(person432, person432).
sameperson(person377, person377).
sameperson(person239, person239).
sameperson(person13, person13).
sameperson(person286, person286).
sameperson(person412, person412).
sameperson(person418, person418).
sameperson(person320, person320).
sameperson(person42, person42).
sameperson(person20, person20).
sameperson(person352, person352).
sameperson(person276, person276).
sameperson(person45, person45).
sameperson(person233, person233).
sameperson(person148, person148).
sameperson(person193, person193).
sameperson(person314, person314).
sameperson(person21, person21).
sameperson(person262, person262).
sameperson(person257, person257).
sameperson(person73, person73).
sameperson(person380, person380).
sameperson(person384, person384).
sameperson(person406, person406).
sameperson(person266, person266).
sameperson(person312, person312).
sameperson(person208, person208).
sameperson(person63, person63).
sameperson(person83, person83).
sameperson(person271, person271).
sameperson(person392, person392).
sameperson(person420, person420).
sameperson(person86, person86).
samecourse(course52, course52).
samecourse(course44, course44).
samecourse(course24, course24).
samecourse(course57, course57).
samecourse(course143, course143).
samecourse(course50, course50).
samecourse(course156, course156).
samecourse(course141, course141).
samecourse(course12, course12).
samecourse(course170, course170).
samecourse(course123, course123).
samecourse(course173, course173).
samecourse(course85, course85).
samecourse(course64, course64).
samecourse(course168, course168).
samecourse(course158, course158).
samecourse(course76, course76).
samecourse(course16, course16).
samecourse(course15, course15).
samecourse(course39, course39).
samecourse(course32, course32).
samecourse(course7, course7).
samecourse(course134, course134).
samecourse(course135, course135).
samecourse(course65, course65).
samecourse(course86, course86).
samecourse(course131, course131).
samecourse(course128, course128).
samecourse(course82, course82).
samecourse(course132, course132).
sameproject(project50, project50).
sameproject(project58, project58).
sameproject(project104, project104).
sameproject(project20, project20).
sameproject(project74, project74).
sameproject(project62, project62).
sameproject(project17, project17).
sameproject(project82, project82).
sameproject(project24, project24).
sameproject(project127, project127).
sameproject(project131, project131).
sameproject(project38, project38).
sameproject(project41, project41).
sameproject(project100, project100).
sameproject(project76, project76).
sameproject(project111, project111).
sameproject(project124, project124).
sameproject(project77, project77).
sameproject(project11, project11).
sameproject(project52, project52).
sameproject(project51, project51).
sameproject(project115, project115).
sameproject(project141, project141).
sameproject(project70, project70).
sameproject(project146, project146).
sameproject(project150, project150).
sameproject(project73, project73).
sameproject(project42, project42).
sameproject(project36, project36).
sameproject(project13, project13).
sameproject(project85, project85).
sameproject(project7, project7).
sameproject(project121, project121).
sameproject(project0, project0).
sameproject(project33, project33).
sameproject(project29, project29).
sameproject(project84, project84).
sameproject(project90, project90).
sameproject(project83, project83).
sameproject(project97, project97).
sameproject(project113, project113).
sameproject(project116, project116).
sameproject(project143, project143).
sameproject(project66, project66).
sameproject(project101, project101).
publication(title25 , person284).
publication(title284 , person14).
publication(title110 , person14).
publication(title118 , person14).
publication(title71 , person14).
publication(title316 , person14).
publication(title118 , person318).
publication(title217 , person161).
publication(title55 , person161).
publication(title331 , person161).
publication(title250 , person161).
publication(title268 , person161).
publication(title271 , person161).
publication(title171 , person161).
publication(title120 , person347).
publication(title86 , person347).
publication(title338 , person347).
publication(title224 , person347).
publication(title260 , person347).
publication(title112 , person347).
publication(title97 , person347).
publication(title50 , person292).
publication(title103 , person292).
publication(title166 , person292).
publication(title72 , person292).
publication(title47 , person292).
publication(title41 , person292).
publication(title40 , person293).
publication(title13 , person240).
publication(title140 , person240).
publication(title217 , person240).
publication(title92 , person240).
publication(title167 , person240).
publication(title331 , person240).
publication(title26 , person240).
publication(title275 , person240).
publication(title333 , person240).
publication(title270 , person240).
publication(title208 , person240).
publication(title103 , person240).
publication(title268 , person240).
publication(title340 , person240).
publication(title192 , person240).
publication(title54 , person240).
publication(title177 , person240).
publication(title33 , person240).
publication(title10 , person240).
publication(title84 , person240).
publication(title161 , person240).
publication(title248 , person240).
publication(title102 , person240).
publication(title274 , person240).
publication(title47 , person240).
publication(title0 , person240).
publication(title82 , person240).
publication(title337 , person240).
publication(title344 , person240).
publication(title254 , person240).
publication(title119 , person240).
publication(title114 , person211).
publication(title259 , person211).
publication(title59 , person211).
publication(title160 , person211).
publication(title88 , person211).
publication(title24 , person211).
publication(title323 , person211).
publication(title190 , person211).
publication(title11 , person211).
publication(title199 , person211).
publication(title240 , person211).
publication(title335 , person211).
publication(title241 , person211).
publication(title212 , person211).
publication(title228 , person211).
publication(title345 , person211).
publication(title89 , person211).
publication(title165 , person211).
publication(title113 , person211).
publication(title233 , person211).
publication(title132 , person211).
publication(title310 , person211).
publication(title218 , person211).
publication(title71 , person211).
publication(title341 , person211).
publication(title207 , person211).
publication(title229 , person211).
publication(title292 , person211).
publication(title49 , person211).
publication(title238 , person211).
publication(title255 , person211).
publication(title329 , person211).
publication(title79 , person211).
publication(title325 , person211).
publication(title44 , person211).
publication(title25 , person211).
publication(title118 , person150).
publication(title140 , person415).
publication(title12 , person415).
publication(title182 , person415).
publication(title122 , person415).
publication(title208 , person415).
publication(title103 , person415).
publication(title347 , person415).
publication(title266 , person415).
publication(title340 , person415).
publication(title269 , person415).
publication(title5 , person415).
publication(title70 , person415).
publication(title179 , person415).
publication(title29 , person415).
publication(title72 , person415).
publication(title47 , person415).
publication(title0 , person415).
publication(title38 , person415).
publication(title290 , person415).
publication(title63 , person415).
publication(title82 , person415).
publication(title283 , person415).
publication(title337 , person415).
publication(title94 , person415).
publication(title147 , person415).
publication(title329 , person415).
publication(title297 , person415).
publication(title79 , person415).
publication(title312 , person415).
publication(title107 , person415).
publication(title273 , person415).
publication(title172 , person415).
publication(title295 , person415).
publication(title41 , person415).
publication(title325 , person415).
publication(title44 , person415).
publication(title87 , person415).
publication(title222 , person415).
publication(title236 , person415).
publication(title258 , person415).
publication(title301 , person415).
publication(title318 , person79).
publication(title115 , person79).
publication(title231 , person79).
publication(title226 , person79).
publication(title195 , person79).
publication(title162 , person185).
publication(title178 , person171).
publication(title225 , person171).
publication(title269 , person171).
publication(title150 , person171).
publication(title70 , person171).
publication(title63 , person171).
publication(title94 , person171).
publication(title147 , person171).
publication(title170 , person171).
publication(title125 , person171).
publication(title90 , person171).
publication(title114 , person407).
publication(title12 , person407).
publication(title259 , person407).
publication(title217 , person407).
publication(title92 , person407).
publication(title182 , person407).
publication(title59 , person407).
publication(title160 , person407).
publication(title55 , person407).
publication(title88 , person407).
publication(title167 , person407).
publication(title24 , person407).
publication(title323 , person407).
publication(title331 , person407).
publication(title190 , person407).
publication(title120 , person407).
publication(title250 , person407).
publication(title11 , person407).
publication(title284 , person407).
publication(title199 , person407).
publication(title240 , person407).
publication(title335 , person407).
publication(title270 , person407).
publication(title241 , person407).
publication(title212 , person407).
publication(title110 , person407).
publication(title268 , person407).
publication(title228 , person407).
publication(title347 , person407).
publication(title266 , person407).
publication(title192 , person407).
publication(title345 , person407).
publication(title5 , person407).
publication(title271 , person407).
publication(title89 , person407).
publication(title165 , person407).
publication(title113 , person407).
publication(title233 , person407).
publication(title179 , person407).
publication(title132 , person407).
publication(title177 , person407).
publication(title310 , person407).
publication(title171 , person407).
publication(title33 , person407).
publication(title218 , person407).
publication(title71 , person407).
publication(title341 , person407).
publication(title207 , person407).
publication(title229 , person407).
publication(title292 , person407).
publication(title316 , person407).
publication(title49 , person407).
publication(title38 , person407).
publication(title238 , person407).
publication(title283 , person407).
publication(title255 , person407).
publication(title224 , person407).
publication(title260 , person407).
publication(title297 , person407).
publication(title312 , person407).
publication(title273 , person407).
publication(title25 , person407).
publication(title258 , person407).
publication(title118 , person408).
publication(title118 , person353).
publication(title40 , person239).
publication(title13 , person13).
publication(title26 , person13).
publication(title275 , person13).
publication(title333 , person13).
publication(title54 , person13).
publication(title10 , person13).
publication(title84 , person13).
publication(title161 , person13).
publication(title248 , person13).
publication(title344 , person13).
publication(title50 , person352).
publication(title208 , person352).
publication(title103 , person352).
publication(title166 , person352).
publication(title314 , person352).
publication(title47 , person352).
publication(title86 , person352).
publication(title82 , person352).
publication(title79 , person352).
publication(title261 , person352).
publication(title87 , person352).
publication(title329 , person45).
publication(title79 , person45).
publication(title325 , person45).
publication(title44 , person45).
publication(title150 , person148).
publication(title125 , person148).
publication(title90 , person148).
publication(title162 , person193).
publication(title170 , person314).
publication(title107 , person314).
publication(title172 , person314).
publication(title295 , person314).
publication(title222 , person314).
publication(title301 , person314).
publication(title25 , person21).
publication(title122 , person262).
publication(title314 , person262).
publication(title29 , person262).
publication(title72 , person262).
publication(title290 , person262).
publication(title86 , person262).
publication(title261 , person262).
publication(title41 , person262).
publication(title102 , person257).
publication(title274 , person257).
publication(title254 , person257).
publication(title119 , person257).
publication(title269 , person73).
publication(title63 , person73).
publication(title318 , person380).
publication(title115 , person380).
publication(title231 , person380).
publication(title226 , person380).
publication(title195 , person380).
publication(title314 , person406).
publication(title86 , person406).
publication(title261 , person406).
publication(title118 , person208).
publication(title182 , person63).
publication(title178 , person63).
publication(title225 , person63).
publication(title5 , person63).
publication(title314 , person63).
publication(title86 , person63).
publication(title147 , person63).
publication(title261 , person63).
publication(title97 , person63).
publication(title222 , person63).
publication(title236 , person63).
publication(title301 , person63).
publication(title325 , person83).

taughtBy(course157, person342, autumn_0001).
taughtBy(course110, person351, winter_0001).
taughtBy(course13, person72, winter_0001).
taughtBy(course67, person394, winter_0001).
taughtBy(course157, person72, spring_0001).
taughtBy(course164, person351, spring_0001).
taughtBy(course0, person40, spring_0001).
taughtBy(course115, person342, spring_0001).
taughtBy(course101, person279, spring_0001).
taughtBy(course153, person394, spring_0001).
taughtBy(course157, person72, autumn_0102).
taughtBy(course110, person351, autumn_0102).
taughtBy(course125, person351, winter_0102).
taughtBy(course28, person394, winter_0102).
taughtBy(course13, person342, winter_0102).
taughtBy(course1, person40, winter_0102).
taughtBy(course157, person394, spring_0102).
taughtBy(course164, person351, spring_0102).
taughtBy(course115, person72, spring_0102).
taughtBy(course153, person342, spring_0102).
taughtBy(course157, person72, autumn_0203).
taughtBy(course110, person351, autumn_0203).
taughtBy(course108, person279, autumn_0203).
taughtBy(course89, person394, winter_0203).
taughtBy(course125, person351, winter_0203).
taughtBy(course13, person342, winter_0203).
taughtBy(course157, person72, spring_0203).
taughtBy(course164, person351, spring_0203).
taughtBy(course115, person342, spring_0203).
taughtBy(course101, person394, spring_0203).
taughtBy(course110, person351, autumn_0304).
taughtBy(course79, person72, autumn_0304).
taughtBy(course89, person394, winter_0304).
taughtBy(course125, person351, winter_0304).
taughtBy(course13, person342, winter_0304).
taughtBy(course157, person342, spring_0304).
taughtBy(course164, person351, spring_0304).
taughtBy(course101, person279, spring_0304).
taughtBy(course136, person394, spring_0304).
courselevel(course89, level_400).
courselevel(course157, level_400).
courselevel(course110, level_400).
courselevel(course41, level_400).
courselevel(course148, level_400).
courselevel(course125, level_400).
courselevel(course93, level_400).
courselevel(course164, level_400).
courselevel(course159, level_400).
courselevel(course28, level_400).
courselevel(course154, level_400).
courselevel(course118, level_400).
courselevel(course107, level_400).
courselevel(course0, level_500).
courselevel(course13, level_500).
courselevel(course115, level_500).
courselevel(course101, level_500).
courselevel(course136, level_500).
courselevel(course150, level_500).
courselevel(course109, level_500).
courselevel(course3, level_500).
courselevel(course108, level_500).
courselevel(course56, level_500).
courselevel(course67, level_500).
courselevel(course153, level_500).
courselevel(course1, level_500).
courselevel(course83, level_500).
courselevel(course79, level_500).
courselevel(course114, level_500).
hasPosition(person40, faculty).
hasPosition(person342, faculty).
hasPosition(person111, faculty_adjunct).
hasPosition(person115, faculty).
hasPosition(person351, faculty).
hasPosition(person72, faculty).
hasPosition(person393, faculty).
hasPosition(person394, faculty).
hasPosition(person279, faculty).
inPhase(person241, post_Quals).
inPhase(person217, post_Generals).
inPhase(person270, pre_Quals).
inPhase(person206, post_Generals).
inPhase(person81, post_Generals).
inPhase(person122, post_Quals).
inPhase(person228, post_Quals).
inPhase(person51, pre_Quals).
inPhase(person41, post_Quals).
inPhase(person163, post_Quals).
inPhase(person435, post_Quals).
inPhase(person404, post_Generals).
inPhase(person363, pre_Quals).
inPhase(person427, post_Quals).
inPhase(person142, post_Generals).
inPhase(person431, pre_Quals).
inPhase(person283, pre_Quals).
inPhase(person149, post_Quals).
inPhase(person300, post_Generals).
inPhase(person200, post_Quals).
inPhase(person157, post_Quals).
inPhase(person113, post_Generals).
tempAdvisedBy(person241, person393).
tempAdvisedBy(person270, person393).
tempAdvisedBy(person51, person72).
tempAdvisedBy(person363, person72).
tempAdvisedBy(person427, person393).
tempAdvisedBy(person431, person393).
tempAdvisedBy(person283, person394).
yearsInProgram(person241, year_3).
yearsInProgram(person217, year_5).
yearsInProgram(person270, year_1).
yearsInProgram(person206, year_6).
yearsInProgram(person81, year_6).
yearsInProgram(person122, year_4).
yearsInProgram(person228, year_3).
yearsInProgram(person51, year_2).
yearsInProgram(person41, year_5).
yearsInProgram(person163, year_4).
yearsInProgram(person435, year_4).
yearsInProgram(person404, year_4).
yearsInProgram(person363, year_3).
yearsInProgram(person427, year_4).
yearsInProgram(person142, year_9).
yearsInProgram(person431, year_2).
yearsInProgram(person283, year_1).
yearsInProgram(person149, year_5).
yearsInProgram(person300, year_8).
yearsInProgram(person200, year_4).
yearsInProgram(person157, year_4).
yearsInProgram(person113, year_4).
ta(course89, person228, winter_0304).
ta(course41, person296, winter_0304).
ta(course41, person36, winter_0304).
ta(course13, person431, winter_0304).
ta(course157, person328, autumn_0304).
ta(course157, person31, autumn_0304).
ta(course110, person61, autumn_0304).
ta(course110, person36, autumn_0304).
ta(course79, person157, autumn_0304).
ta(course79, person119, autumn_0304).
ta(course118, person296, summer_0203).
ta(course118, person317, summer_0203).
ta(course157, person119, spring_0203).
ta(course157, person230, spring_0203).
ta(course157, person3, spring_0203).
ta(course157, person258, spring_0203).
ta(course101, person241, spring_0203).
ta(course89, person188, winter_0203).
ta(course89, person41, winter_0203).
ta(course148, person327, winter_0203).
ta(course148, person140, winter_0203).
ta(course13, person51, winter_0203).
ta(course157, person321, autumn_0203).
ta(course157, person428, autumn_0203).
ta(course157, person3, autumn_0203).
ta(course157, person158, autumn_0203).
ta(course110, person327, autumn_0203).
ta(course110, person317, autumn_0203).
ta(course3, person431, autumn_0203).
ta(course150, person327, summer_0102).
ta(course150, person102, summer_0102).
ta(course157, person90, spring_0102).
ta(course157, person214, spring_0102).
ta(course157, person146, spring_0102).
ta(course157, person88, spring_0102).
ta(course93, person228, spring_0102).
ta(course93, person31, spring_0102).
ta(course93, person178, spring_0102).
ta(course153, person195, spring_0102).
ta(course153, person428, spring_0102).
ta(course148, person31, winter_0102).
ta(course159, person113, winter_0102).
ta(course13, person217, winter_0102).
taughtBy(course41 , person351, winter_0304).
taughtBy(course118, person351, summer_0203).
taughtBy(course148, person351, winter_0203).
taughtBy(course3 , person279, autumn_0203).
taughtBy(course150 , person351, summer_0102).
taughtBy(course93, person351, spring_0102).
taughtBy(course148, person351, winter_0102).
taughtBy(course159, person394, winter_0102).
professor(person40).
professor(person279).
professor(person394).
student(person38).
student(person261).
student(person149).
student(person306).
student(person410).
student(person157).
student(person200).
student(person404).
student(person122).
student(person322).
student(person131).
student(person85).
professor(person342).
professor(person111).
professor(person115).
professor(person351).
professor(person72).
professor(person393).
student(person241).
student(person217).
student(person270).
student(person206).
student(person81).
student(person228).
student(person51).
student(person41).
student(person163).
student(person435).
student(person363).
student(person427).
student(person142).
student(person431).
student(person283).
student(person300).
student(person113).
student(person296).
student(person36).
student(person328).
student(person31).
student(person61).
student(person119).
student(person3).
student(person317).
student(person230).
student(person258).
student(person188).
student(person327).
student(person140).
student(person321).
student(person428).
student(person158).
student(person102).
student(person90).
student(person214).
student(person146).
student(person88).
student(person178).
student(person195).
sameperson(person40, person40).
sameperson(person279, person279).
sameperson(person394, person394).
sameperson(person38, person38).
sameperson(person261, person261).
sameperson(person149, person149).
sameperson(person306, person306).
sameperson(person410, person410).
sameperson(person157, person157).
sameperson(person200, person200).
sameperson(person404, person404).
sameperson(person122, person122).
sameperson(person322, person322).
sameperson(person131, person131).
sameperson(person85, person85).
sameperson(person342, person342).
sameperson(person111, person111).
sameperson(person115, person115).
sameperson(person351, person351).
sameperson(person72, person72).
sameperson(person393, person393).
sameperson(person241, person241).
sameperson(person217, person217).
sameperson(person270, person270).
sameperson(person206, person206).
sameperson(person81, person81).
sameperson(person228, person228).
sameperson(person51, person51).
sameperson(person41, person41).
sameperson(person163, person163).
sameperson(person435, person435).
sameperson(person363, person363).
sameperson(person427, person427).
sameperson(person142, person142).
sameperson(person431, person431).
sameperson(person283, person283).
sameperson(person300, person300).
sameperson(person113, person113).
sameperson(person296, person296).
sameperson(person36, person36).
sameperson(person328, person328).
sameperson(person31, person31).
sameperson(person61, person61).
sameperson(person119, person119).
sameperson(person3, person3).
sameperson(person317, person317).
sameperson(person230, person230).
sameperson(person258, person258).
sameperson(person188, person188).
sameperson(person327, person327).
sameperson(person140, person140).
sameperson(person321, person321).
sameperson(person428, person428).
sameperson(person158, person158).
sameperson(person102, person102).
sameperson(person90, person90).
sameperson(person214, person214).
sameperson(person146, person146).
sameperson(person88, person88).
sameperson(person178, person178).
sameperson(person195, person195).
samecourse(course89, course89).
samecourse(course157, course157).
samecourse(course110, course110).
samecourse(course125, course125).
samecourse(course164, course164).
samecourse(course28, course28).
samecourse(course107, course107).
samecourse(course0, course0).
samecourse(course13, course13).
samecourse(course115, course115).
samecourse(course101, course101).
samecourse(course136, course136).
samecourse(course108, course108).
samecourse(course67, course67).
samecourse(course153, course153).
samecourse(course1, course1).
samecourse(course83, course83).
samecourse(course79, course79).
samecourse(course114, course114).
samecourse(course148, course148).
samecourse(course93, course93).
samecourse(course159, course159).
samecourse(course154, course154).
samecourse(course118, course118).
samecourse(course109, course109).
samecourse(course56, course56).
samecourse(course41, course41).
samecourse(course150, course150).
samecourse(course3, course3).
sameproject(project103, project103).
sameproject(project91, project91).
sameproject(project96, project96).
sameproject(project15, project15).
sameproject(project140, project140).
sameproject(project78, project78).
sameproject(project47, project47).
sameproject(project106, project106).
sameproject(project118, project118).
sameproject(project133, project133).
sameproject(project34, project34).
sameproject(project151, project151).
sameproject(project81, project81).
sameproject(project123, project123).
sameproject(project23, project23).
sameproject(project132, project132).
sameproject(project71, project71).
sameproject(project135, project135).
sameproject(project149, project149).
sameproject(project25, project25).
sameproject(project65, project65).
sameproject(project6, project6).
sameproject(project88, project88).
sameproject(project54, project54).
sameproject(project105, project105).
sameproject(project46, project46).
sameproject(project142, project142).
sameproject(project48, project48).
sameproject(project2, project2).
sameproject(project92, project92).
sameproject(project86, project86).
sameproject(project19, project19).
sameproject(project139, project139).
sameproject(project117, project117).
sameproject(project98, project98).
sameproject(project59, project59).
sameproject(project145, project145).
sameproject(project69, project69).
sameproject(project53, project53).
sameproject(project107, project107).
sameproject(project136, project136).
sameproject(project87, project87).
sameproject(project45, project45).
sameproject(project79, project79).
sameproject(project35, project35).
sameproject(project49, project49).
publication(title322 , person40).
publication(title346 , person40).
publication(title1 , person40).
publication(title183 , person394).
publication(title30 , person394).
publication(title153 , person306).
publication(title111 , person306).
publication(title15 , person410).
publication(title45 , person410).
publication(title60 , person410).
publication(title93 , person410).
publication(title272 , person410).
publication(title116 , person410).
publication(title203 , person404).
publication(title185 , person404).
publication(title201 , person404).
publication(title137 , person322).
publication(title109 , person342).
publication(title181 , person342).
publication(title135 , person342).
publication(title15 , person342).
publication(title45 , person342).
publication(title263 , person342).
publication(title35 , person342).
publication(title272 , person342).
publication(title116 , person342).
publication(title85 , person342).
publication(title304 , person342).
publication(title302 , person342).
publication(title137 , person342).
publication(title183 , person72).
publication(title30 , person72).
publication(title201 , person72).
publication(title302 , person72).
publication(title137 , person72).
publication(title109 , person393).
publication(title153 , person393).
publication(title123 , person393).
publication(title181 , person393).
publication(title135 , person393).
publication(title45 , person393).
publication(title60 , person393).
publication(title93 , person393).
publication(title35 , person393).
publication(title220 , person393).
publication(title272 , person393).
publication(title116 , person393).
publication(title111 , person393).
publication(title4 , person393).
publication(title85 , person393).
publication(title304 , person393).
publication(title322 , person393).
publication(title346 , person393).
publication(title1 , person393).
publication(title304 , person241).
publication(title302 , person217).
publication(title137 , person206).
publication(title109 , person81).
publication(title45 , person81).
publication(title116 , person81).
publication(title304 , person81).
publication(title100 , person41).
publication(title99 , person435).
publication(title123 , person142).
publication(title263 , person142).
publication(title220 , person142).
publication(title99 , person300).
publication(title181 , person300).
publication(title35 , person300).
publication(title4 , person300).
publication(title203 , person113).
publication(title185 , person113).
publication(title100 , person113).


taughtBy(course51, person5, autumn_0001).
taughtBy(course172, person335, autumn_0001).
taughtBy(course46, person335, winter_0001).
taughtBy(course71, person5, winter_0001).
taughtBy(course124, person335, spring_0001).
taughtBy(course51, person166, autumn_0102).
taughtBy(course49, person263, winter_0102).
taughtBy(course19, person5, winter_0102).
taughtBy(course63, person335, spring_0102).
taughtBy(course51, person18, autumn_0203).
taughtBy(course53, person248, autumn_0203).
taughtBy(course172, person335, autumn_0203).
taughtBy(course49, person248, winter_0203).
taughtBy(course46, person335, winter_0203).
taughtBy(course146, person335, spring_0203).
taughtBy(course49, person248, spring_0203).
taughtBy(course53, person189, autumn_0304).
taughtBy(course172, person46, autumn_0304).
taughtBy(course138, person335, autumn_0304).
taughtBy(course124, person9, winter_0304).
taughtBy(course49, person64, winter_0304).
taughtBy(course46, person335, winter_0304).
taughtBy(course146, person335, spring_0304).
taughtBy(course124, person46, spring_0304).
taughtBy(course49, person189, spring_0304).
taughtBy(course19, person370, spring_0304).
courselevel(course146, level_300).
courselevel(course124, level_300).
courselevel(course51, level_400).
courselevel(course49, level_400).
courselevel(course53, level_400).
courselevel(course46, level_500).
courselevel(course19, level_500).
courselevel(course172, level_500).
courselevel(course71, level_500).
courselevel(course63, level_500).
courselevel(course152, level_500).
courselevel(course54, level_500).
courselevel(course138, level_500).
courselevel(course35, level_500).
hasPosition(person335, faculty).
hasPosition(person46, faculty).
hasPosition(person189, faculty_adjunct).
hasPosition(person5, faculty).
inPhase(person18, pre_Quals).
inPhase(person9, post_Generals).
inPhase(person429, post_Quals).
inPhase(person27, pre_Quals).
inPhase(person362, post_Quals).
inPhase(person96, post_Generals).
inPhase(person361, post_Generals).
inPhase(person263, post_Generals).
inPhase(person183, pre_Quals).
inPhase(person118, post_Generals).
tempAdvisedBy(person27, person335).
yearsInProgram(person18, year_3).
yearsInProgram(person9, year_5).
yearsInProgram(person429, year_5).
yearsInProgram(person27, year_1).
yearsInProgram(person362, year_3).
yearsInProgram(person96, year_5).
yearsInProgram(person361, year_6).
yearsInProgram(person263, year_6).
yearsInProgram(person183, year_4).
yearsInProgram(person118, year_4).
ta(course49, person361, winter_0304).
ta(course46, person429, winter_0304).
ta(course124, person105, autumn_0304).
ta(course51, person27, autumn_0304).
ta(course138, person18, autumn_0304).
ta(course49, person361, summer_0203).
ta(course124, person108, spring_0203).
ta(course124, person203, spring_0203).
ta(course51, person96, spring_0203).
ta(course49, person287, spring_0203).
ta(course49, person87, spring_0203).
ta(course124, person18, winter_0203).
ta(course124, person35, winter_0203).
ta(course49, person287, winter_0203).
ta(course49, person87, winter_0203).
ta(course46, person429, winter_0203).
ta(course124, person108, autumn_0203).
ta(course124, person203, autumn_0203).
ta(course53, person287, autumn_0203).
ta(course172, person325, autumn_0203).
ta(course49, person361, summer_0102).
ta(course51, person39, spring_0102).
ta(course124, person76, winter_0102).
ta(course124, person9, winter_0102).
ta(course49, person96, winter_0102).
ta(course19, person232, winter_0102).
taughtBy(course53, person248, autumn_0304).
taughtBy(course49, person64, summer_0203).
taughtBy(course49, person64, summer_0102).
professor(person248).
professor(person64).
professor(person166).
professor(person370).
professor(person335).
professor(person46).
professor(person189).
professor(person5).
student(person18).
student(person9).
student(person429).
student(person27).
student(person362).
student(person96).
student(person361).
student(person263).
student(person183).
student(person118).
student(person105).
student(person108).
student(person203).
student(person287).
student(person87).
student(person39).
student(person35).
student(person325).
student(person76).
student(person232).
sameperson(person248, person248).
sameperson(person64, person64).
sameperson(person166, person166).
sameperson(person370, person370).
sameperson(person335, person335).
sameperson(person46, person46).
sameperson(person189, person189).
sameperson(person5, person5).
sameperson(person18, person18).
sameperson(person9, person9).
sameperson(person429, person429).
sameperson(person27, person27).
sameperson(person362, person362).
sameperson(person96, person96).
sameperson(person361, person361).
sameperson(person263, person263).
sameperson(person183, person183).
sameperson(person118, person118).
sameperson(person105, person105).
sameperson(person108, person108).
sameperson(person203, person203).
sameperson(person287, person287).
sameperson(person87, person87).
sameperson(person39, person39).
sameperson(person35, person35).
sameperson(person325, person325).
sameperson(person76, person76).
sameperson(person232, person232).
samecourse(course146, course146).
samecourse(course124, course124).
samecourse(course51, course51).
samecourse(course49, course49).
samecourse(course53, course53).
samecourse(course46, course46).
samecourse(course19, course19).
samecourse(course172, course172).
samecourse(course71, course71).
samecourse(course63, course63).
samecourse(course152, course152).
samecourse(course54, course54).
samecourse(course138, course138).
samecourse(course35, course35).
sameproject(project9, project9).
sameproject(project102, project102).
sameproject(project108, project108).
sameproject(project89, project89).
sameproject(project147, project147).
sameproject(project3, project3).
sameproject(project95, project95).
sameproject(project120, project120).
publication(title106 , person335).
publication(title14 , person335).
publication(title130 , person335).
publication(title106 , person5).
publication(title130 , person5).
publication(title257 , person429).
publication(title142 , person429).
publication(title14 , person429).
publication(title257 , person183).
publication(title142 , person183).
